const { AppDataSource } = require('../data-source')
const JobSchema = require('../entities/Job')

const jobRepo = () => AppDataSource.getRepository('Job')

// ─── Créer un job ─────────────────────────────────────────────────────
const createJob = async (jobData, userId) => {
  // Utilise directement le schéma exporté
  const jobRepository = AppDataSource.getRepository(JobSchema);
  
  const newJob = jobRepository.create({
    ...jobData,
    recruiter: { id: userId } // Correspond à ta relation Many-to-One
  });

  return await jobRepository.save(newJob);
};

// ─── Tous les jobs ────────────────────────────────────────────────────
const getAllJobs = async () => {
  const repo = jobRepo()
  return repo.find({
    order: { createdAt: 'DESC' },
  })
}

// ─── Jobs par recruteur ───────────────────────────────────────────────
const getMyJobs = async (recruiterId) => {
  const repo = jobRepo()
  return repo.find({
    where:  { recruiter: { id: recruiterId } },
    order:  { createdAt: 'DESC' },
  })
}

// ─── Un job par id ────────────────────────────────────────────────────
const getJobById = async (id) => {
  const repo = jobRepo()
  const job  = await repo.findOne({ where: { id } })
  if (!job) throw { status: 404, message: 'Job introuvable' }
  return job
}

// ─── Supprimer un job ─────────────────────────────────────────────────
const deleteJob = async (id, recruiterId) => {
  const repo = jobRepo()
  const job  = await repo.findOne({ where: { id } })

  if (!job)
    throw { status: 404, message: 'Job introuvable' }
  if (job.recruiter?.id !== recruiterId)
    throw { status: 403, message: 'Action non autorisée' }

  await repo.remove(job)
  return { message: 'Job supprimé avec succès' }
}

module.exports = { createJob, getAllJobs, getMyJobs, getJobById, deleteJob }