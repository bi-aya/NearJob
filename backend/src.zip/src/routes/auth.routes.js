const express      = require('express')
const router       = express.Router()
const authService  = require('../services/auth.service')
const verifyToken  = require('../utils/verifyToken')
const { validateRegisterDto, validateLoginDto } = require('../dto/auth.dto')
 
// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const errors = validateRegisterDto(req.body)
    if (errors.length > 0)
      return res.status(400).json({ message: errors[0], errors })
 
    const data = await authService.register(req.body)
    res.status(201).json(data)
  } catch (err) {
    res.status(err.status || 500).json({ message: err.message })
  }
})
 
// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const errors = validateLoginDto(req.body)
    if (errors.length > 0)
      return res.status(400).json({ message: errors[0], errors })
 
    const data = await authService.login(req.body)
    res.status(200).json(data)
  } catch (err) {
    res.status(err.status || 500).json({ message: err.message })
  }
})
 
// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body
    if (!refreshToken)
      return res.status(400).json({ message: 'Refresh token requis' })
 
    const tokens = authService.refreshTokens(refreshToken)
    res.status(200).json(tokens)
  } catch (err) {
    res.status(err.status || 500).json({ message: err.message })
  }
})
 
// GET /api/auth/me — protégée
router.get('/me', async (req, res) => {
  try {
    const decoded = verifyToken(req)
    const user    = await authService.getMe(decoded.id)
    res.status(200).json(user)
  } catch (err) {
    res.status(err.status || 500).json({ message: err.message })
  }
})
 
module.exports = router
