const { IsString, IsOptional, IsNumber, IsBoolean, IsUrl, Length } = require('class-validator');

class UpdateUserDto {
  @IsOptional() @IsString() firstName;
  @IsOptional() @IsString() lastName;
  @IsOptional() @IsString() @Length(0, 500) bio;
  @IsOptional() @IsString() category;
  @IsOptional() @IsNumber() dailyRate;
  @IsOptional() @IsString() city;
  @IsOptional() @IsBoolean() isAvailable;
  
  @IsOptional() @IsUrl({}, { message: "URL LinkedIn invalide" }) linkedin_url;
  @IsOptional() @IsUrl({}, { message: "URL GitHub invalide" }) github_url;
  @IsOptional() @IsUrl({}, { message: "URL Portfolio invalide" }) portfolio_url;
}

module.exports = { UpdateUserDto };