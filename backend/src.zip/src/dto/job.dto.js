const { IsString, IsNotEmpty, MinLength, IsNumber, IsOptional, IsEnum } = require('class-validator');

class CreateJobDto {
  @IsString() @MinLength(5) title;
  @IsString() @MinLength(20) description;
  @IsString() category;
  @IsEnum(['freelance', 'cdi_cdd', 'stage']) type;
  @IsOptional() @IsNumber() budget;
  @IsOptional() @IsEnum(['fixed', 'daily', 'monthly']) budgetType;
  @IsOptional() @IsString() city;
}

module.exports = { CreateJobDto };