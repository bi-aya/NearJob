const { IsEmail, IsString, MinLength, IsEnum, IsOptional } = require('class-validator');

class RegisterDto {
  @IsEmail({}, { message: "Email invalide" }) email;
  @IsString() @MinLength(6, { message: "6 caractères min." }) password;
  @IsEnum(['freelance', 'recruiter']) role;
}

class LoginDto {
  @IsEmail() email;
  @IsString() password;
}

module.exports = { RegisterDto, LoginDto };